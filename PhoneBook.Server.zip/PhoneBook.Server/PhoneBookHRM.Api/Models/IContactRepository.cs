﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PhoneBookHRM.Shared;

namespace PhoneBookHRM.Api.Models
{
    public interface IContactRepository
    {
        IEnumerable<Contact> GetAllContacts();
        Contact GetContactById(int ContactId);
        Contact AddContact(Contact Contact);
        Contact UpdateContact(Contact Contact);
        void DeleteContact(int ContactId);
    }
}
