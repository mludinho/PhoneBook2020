﻿using System.Collections.Generic;
using System.Linq;
using PhoneBookHRM.Shared;

namespace PhoneBookHRM.Api.Models
{
    public class ContactRepository : IContactRepository
    {
        private readonly AppDbContext _appDbContext;

        public ContactRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Contact> GetAllContacts()
        {
            return _appDbContext.Contacts;
        }

        public Contact GetContactById(int ContactId)
        {
            return _appDbContext.Contacts.FirstOrDefault(c => c.ContactId == ContactId);
        }

        public Contact AddContact(Contact Contact)
        {
            var addedEntity = _appDbContext.Contacts.Add(Contact);
            _appDbContext.SaveChanges();
            return addedEntity.Entity;
        }

        public Contact UpdateContact(Contact Contact)
        {
            var foundContact = _appDbContext.Contacts.FirstOrDefault(e => e.ContactId == Contact.ContactId);

            if (foundContact != null)
            {
                foundContact.CountryId = Contact.CountryId;
                foundContact.BirthDate = Contact.BirthDate;
                foundContact.City = Contact.City;
                foundContact.Email = Contact.Email;
                foundContact.FirstName = Contact.FirstName;
                foundContact.LastName = Contact.LastName;
                foundContact.Gender = Contact.Gender;
                foundContact.PhoneNumber = Contact.PhoneNumber;
                foundContact.Street = Contact.Street;
                foundContact.Zip = Contact.Zip;

                _appDbContext.SaveChanges();

                return foundContact;
            }

            return null;
        }

        public void DeleteContact(int ContactId)
        {
            var foundContact = _appDbContext.Contacts.FirstOrDefault(e => e.ContactId == ContactId);
            if (foundContact == null) return;

            _appDbContext.Contacts.Remove(foundContact);
            _appDbContext.SaveChanges();
        }
    }
}
