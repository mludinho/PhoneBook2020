﻿using PhoneBookHRM.Api.Models;
using PhoneBookHRM.Shared;
using Microsoft.AspNetCore.Mvc;

namespace PhoneBookHRM.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : Controller
    {
        private readonly IContactRepository _ContactRepository;

        public ContactController(IContactRepository ContactRepository)
        {
            _ContactRepository = ContactRepository;
        }

        [HttpGet]
        public IActionResult GetAllContacts()
        {
            return Ok(_ContactRepository.GetAllContacts());
        }

        [HttpGet("{id}")]
        public IActionResult GetContactById(int id)
        {
            return Ok(_ContactRepository.GetContactById(id));
        }

        [HttpPost]
        public IActionResult CreateContact([FromBody] Contact Contact)
        {
            if (Contact == null)
                return BadRequest();

            if (Contact.FirstName == string.Empty || Contact.LastName == string.Empty)
            {
                ModelState.AddModelError("Name/FirstName", "The name or first name shouldn't be empty");
            }

            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            Contact.Email = "xxx@xxxx.xom";
            Contact.CountryId = 1;
            var createdContact = _ContactRepository.AddContact(Contact);

            return Created("Contact", createdContact);
        }

        [HttpPut]
        public IActionResult UpdateContact([FromBody] Contact Contact)
        {
            if (Contact == null)
                return BadRequest();

            if (Contact.FirstName == string.Empty || Contact.LastName == string.Empty)
            {
                ModelState.AddModelError("Name/FirstName", "The name or first name shouldn't be empty");
            }

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var ContactToUpdate = _ContactRepository.GetContactById(Contact.ContactId);

            if (ContactToUpdate == null)
                return NotFound();

            _ContactRepository.UpdateContact(Contact);

            return NoContent(); //success
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContact(int id)
        {
            if (id == 0)
                return BadRequest();

            var ContactToDelete = _ContactRepository.GetContactById(id);
            if (ContactToDelete == null)
                return NotFound();

            _ContactRepository.DeleteContact(id);

            return NoContent();//success
        }
    }
}
