﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PhoneBookHRM.ComponentsLibrary.Map;
using PhoneBookHRM.Server.Services;
using PhoneBookHRM.Shared;
using Microsoft.AspNetCore.Components;

namespace PhoneBookHRM.Server.Pages
{
    public class ContactDetailBase : ComponentBase
    {
        [Inject]
        public IContactDataService ContactDataService { get; set; }

        [Inject]
        public IJobCategoryDataService JobCategoryDataService{ get; set; }

        [Parameter]
        public string ContactId { get; set; }

        public List<Marker> MapMarkers { get; set; } = new List<Marker>();

        protected string JobCategory = string.Empty;
       
        public Contact Contact { get; set; } = new Contact();

        protected override async Task OnInitializedAsync()
        {
            Contact = await ContactDataService.GetContactDetails(int.Parse(ContactId));

            MapMarkers = new List<Marker>
            {
                new Marker{Description = $"{Contact.FirstName} {Contact.LastName}",  ShowPopup = false}
            };
        }
    }
}
