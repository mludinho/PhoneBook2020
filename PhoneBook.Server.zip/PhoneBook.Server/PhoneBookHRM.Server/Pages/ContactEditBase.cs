﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PhoneBookHRM.Server.Services;
using PhoneBookHRM.Shared;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;

namespace PhoneBookHRM.Server.Pages
{
    public class ContactEditBase : ComponentBase
    {
        [Inject]
        public IContactDataService ContactDataService { get; set; }

        [Inject]
        public ICountryDataService CountryDataService { get; set; }

        [Inject] 
        public NavigationManager NavigationManager { get; set; }

        [Parameter]
        public string ContactId { get; set; }
        public InputText LastNameInputText { get; set; }

        public Contact Contact { get; set; } = new Contact();

        //needed to bind to select to value
        protected string CountryId = string.Empty;

        //used to store state of screen
        protected string Message = string.Empty;
        protected string StatusClass = string.Empty;
        protected bool Saved;

        public List<Country> Countries { get; set; } = new List<Country>();

        protected override async Task OnInitializedAsync()
        {
            Saved = false;
            Countries = (await CountryDataService.GetAllCountries()).ToList();
            int contactIDObj = 0;
            int.TryParse(ContactId, out contactIDObj);

            if (contactIDObj == 0) //new Contact is being created
            {
                //add some defaults
                Contact = new Contact { CountryId = 1, BirthDate = DateTime.Now };
            }
            else
            {
                Contact = await ContactDataService.GetContactDetails(int.Parse(ContactId));
            }

            CountryId = Contact.CountryId.ToString();
 
        }

        protected async Task HandleValidSubmit()
        {
            Contact.CountryId = int.Parse(CountryId);

            if (Contact.ContactId == 0) //new
            {
                var addedContact = await ContactDataService.AddContact(Contact);
                if (addedContact != null)
                {
                    StatusClass = "alert-success";
                    Message = "New Contact added successfully.";
                    Saved = true;
                }
                else
                {
                    StatusClass = "alert-danger";
                    Message = "Something went wrong adding the new Contact. Please try again.";
                    Saved = false;
                }
            }
            else
            {
                await ContactDataService.UpdateContact(Contact);
                StatusClass = "alert-success";
                Message = "Contact updated successfully.";
                Saved = true;
            }
        }

        protected void HandleInvalidSubmit()
        {
            StatusClass = "alert-danger";
            Message = "There are some validation errors. Please try again.";
        }

        protected async Task DeleteContact()
        {
            await ContactDataService.DeleteContact(Contact.ContactId);

            StatusClass = "alert-success";
            Message = "Deleted successfully";

            Saved = true;
        }

        protected void NavigateToOverview()
        {
            NavigationManager.NavigateTo("/Contactoverview");
        }
    }
}
