﻿using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using PhoneBookHRM.Server.Components;
using PhoneBookHRM.Server.Services;
using PhoneBookHRM.Shared;
using Microsoft.AspNetCore.Components;

namespace PhoneBookHRM.Server.Pages
{
    public class ContactOverviewBase: ComponentBase
    {
        [Inject]
        public IContactDataService ContactDataService { get; set; }

        public List<Contact> Contacts { get; set; }
        public List<Contact> ContactsCopy { get; set; }

        private string searchTerm;
        public string SearchTerm
        {
            get { return searchTerm; }
            set { searchTerm = value; FilterRecords(); }
            
        }
        public void FilterRecords() {
            Contacts = ContactsCopy;
            Contacts = Contacts.Where(x => x.FirstName.ToLower().Contains(SearchTerm.ToLower()) 
            || x.LastName.ToLower().Contains(SearchTerm.ToLower()) 
            || x.PhoneNumber.ToLower().Contains(SearchTerm.ToLower())).ToList();
        }

        protected AddContactDialog AddContactDialog { get; set; }

        protected override async Task OnInitializedAsync()
        {
            Contacts = (await ContactDataService.GetAllContacts()).ToList();
            ContactsCopy = Contacts;
        }

        public async void AddContactDialog_OnDialogClose()
        {

            Contacts = (await ContactDataService.GetAllContacts()).ToList();
            StateHasChanged();
        }

        protected void QuickAddContact()
        {
            AddContactDialog.Show();
        }
    }
}
