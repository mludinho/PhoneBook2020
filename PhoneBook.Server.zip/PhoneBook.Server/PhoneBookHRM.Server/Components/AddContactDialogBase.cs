﻿using System;
using System.Threading.Tasks;
using PhoneBookHRM.Server.Services;
using PhoneBookHRM.Shared;
using Microsoft.AspNetCore.Components;

namespace PhoneBookHRM.Server.Components
{
    public class AddContactDialogBase : ComponentBase
    {
        public bool ShowDialog { get; set; }

        public Contact Contact { get; set; } = new Contact { BirthDate = DateTime.Now };

        [Parameter]
        public EventCallback<bool> CloseEventCallback { get; set; }

        [Inject] 
        public IContactDataService ContactDataService { get; set; }

      

        public void Show()
        {
            ResetDialog();
            ShowDialog = true;
            StateHasChanged();
        }

        private void ResetDialog()
        {
            Contact = new Contact {BirthDate = DateTime.Now};
        }

        public void Close()
        {
            ShowDialog = false;
            StateHasChanged();
        }

        protected async Task HandleValidSubmit()
        {
            await ContactDataService.AddContact(Contact);
            ShowDialog = false;

            await CloseEventCallback.InvokeAsync(true);
            StateHasChanged();
        }
    }
}
