﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PhoneBookHRM.Shared;

namespace PhoneBookHRM.Server.Services
{
    public interface IContactDataService
    {
        Task<IEnumerable<Contact>> GetAllContacts();
        Task<Contact> GetContactDetails(int ContactId);
        Task<Contact> AddContact(Contact Contact);
        Task UpdateContact(Contact Contact);
        Task DeleteContact(int ContactId);
    }
}
