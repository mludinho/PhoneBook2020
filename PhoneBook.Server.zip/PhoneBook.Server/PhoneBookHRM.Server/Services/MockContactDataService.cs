﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PhoneBookHRM.Shared;

namespace PhoneBookHRM.Server.Services
{
    public class MockContactDataService : IContactDataService
    {
        private List<Contact> _Contacts;
        private List<Country> _countries;
        private List<JobCategory> _jobCategories;

        private IEnumerable<Contact> Contacts
        {
            get
            {
                if (_Contacts == null)
                    InitializeContacts();
                return _Contacts;
            }
        }

        private List<Country> Countries
        {
            get
            {
                if (_countries == null)
                    InitializeCountries();
                return _countries;
            }
        }


        private void InitializeCountries()
        {
            _countries = new List<Country>
            {
                new Country {CountryId = 1, Name = "South Africa"},
                new Country {CountryId = 2, Name = "Netherlands"},
                new Country {CountryId = 3, Name = "USA"},
                new Country {CountryId = 4, Name = "Japan"},
                new Country {CountryId = 5, Name = "China"},
                new Country {CountryId = 6, Name = "UK"},
                new Country {CountryId = 7, Name = "France"},
                new Country {CountryId = 8, Name = "Brazil"}
            };
        }

        private void InitializeContacts()
        {
            if (_Contacts == null)
            {
                Contact e1 = new Contact
                {
                    CountryId = 1,
                    BirthDate = new DateTime(1984, 10, 30),
                    City = "Cosmo City",
                    Email = "cosmo@gmail.com",
                    ContactId = 1,
                    FirstName = "Silver",
                    LastName = "Fox",
                    Gender = Gender.Male,
                    PhoneNumber = "011 345 3005",
                    Street = "Moriting Park",
                    Zip = "3200",
                };
                _Contacts = new List<Contact>() { e1 };
            }
        }

        public async Task<IEnumerable<Contact>> GetAllContacts()
        {
            return await Task.Run(() => Contacts);
        }

        public async Task<List<Country>> GetAllCountries()
        {
            return await Task.Run(() => Countries);
        }

        public async Task<Contact> GetContactDetails(int ContactId)
        {
            return await Task.Run(() => { return Contacts.FirstOrDefault(e => e.ContactId == ContactId); });
        }

        public Task<Contact> AddContact(Contact Contact)
        {
            throw new NotImplementedException();
        }

        public Task DeleteContact(int ContactId)
        {
            throw new NotImplementedException();
        }

        public Task UpdateContact(Contact Contact)
        {
            throw new NotImplementedException();
        }
    }
}
