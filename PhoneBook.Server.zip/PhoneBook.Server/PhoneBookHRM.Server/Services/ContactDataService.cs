﻿using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using PhoneBookHRM.Shared;

namespace PhoneBookHRM.Server.Services
{
    public class ContactDataService : IContactDataService
    {
        private readonly HttpClient _httpClient;

        public ContactDataService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IEnumerable<Contact>> GetAllContacts()
        {
            return await JsonSerializer.DeserializeAsync<IEnumerable<Contact>>
                (await _httpClient.GetStreamAsync($"api/Contact"), new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
        }

        public async Task<Contact> GetContactDetails(int ContactId)
        {
            return await JsonSerializer.DeserializeAsync<Contact>
                (await _httpClient.GetStreamAsync($"api/Contact/{ContactId}"), new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
        }

        public async Task<Contact> AddContact(Contact Contact)
        {
            var ContactJson =
                new StringContent(JsonSerializer.Serialize(Contact), Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("api/Contact", ContactJson);

            if (response.IsSuccessStatusCode)
            {
                return await JsonSerializer.DeserializeAsync<Contact>(await response.Content.ReadAsStreamAsync());
            }

            return null;
        }

        public async Task UpdateContact(Contact Contact)
        {
            var ContactJson =
                new StringContent(JsonSerializer.Serialize(Contact), Encoding.UTF8, "application/json");

            await _httpClient.PutAsync("api/Contact", ContactJson);
        }

        public async Task DeleteContact(int ContactId)
        {
            await _httpClient.DeleteAsync($"api/Contact/{ContactId}");
        }
    }
}
