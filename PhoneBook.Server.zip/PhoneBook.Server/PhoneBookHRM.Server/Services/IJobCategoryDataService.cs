﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PhoneBookHRM.Shared;

namespace PhoneBookHRM.Server.Services
{
    public interface IJobCategoryDataService
    {
        Task<IEnumerable<JobCategory>> GetAllJobCategories();
        Task<JobCategory> GetJobCategoryById(int jobCategoryId);
    }
}
