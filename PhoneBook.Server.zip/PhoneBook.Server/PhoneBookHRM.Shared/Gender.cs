﻿namespace PhoneBookHRM.Shared
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
