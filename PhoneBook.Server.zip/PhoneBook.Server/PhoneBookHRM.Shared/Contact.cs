﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PhoneBookHRM.Shared
{
    public class Contact
    {
        public int ContactId { get; set; }
        [Required]
        [StringLength(50, ErrorMessage = "First name is too long.")]
        public string FirstName { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "Last name is too long.")]
        public string LastName { get; set; }

        public DateTime BirthDate { get; set; }

        [EmailAddress]
        public string Email { get; set; }
        public string Street { get; set; }
        public string Zip { get; set; }
        public string City { get; set; }
        public int CountryId { get; set; }
        public Country Country { get; set; }
        [Required]
        public string PhoneNumber { get; set; }
        public Gender Gender { get; set; }
    }
}
