﻿namespace PhoneBookHRM.Shared
{
    public enum MaritalStatus
    {
        Married,
        Single,
        Other
    }
}